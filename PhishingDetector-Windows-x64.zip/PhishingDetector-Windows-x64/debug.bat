java -jar PhishingDetector.jar
pause
