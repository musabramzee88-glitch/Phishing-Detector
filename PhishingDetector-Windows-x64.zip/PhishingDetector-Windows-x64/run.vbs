Set WshShell = CreateObject("WScript.Shell")
strPath = WScript.ScriptFullName
Set objFSO = CreateObject("Scripting.FileSystemObject")
strFolder = objFSO.GetParentFolderName(strPath)
WshShell.CurrentDirectory = strFolder

' تنظيف أي عملية سابقة محتجزة للمنفذ 9000 في الخلفية بصمت تام
WshShell.Run "cmd.exe /c for /f ""tokens=5"" %a in ('netstat -a -n -o ^| findstr :9000') do taskkill /f /pid %a >nul 2>&1", 0, True

' تشغيل السيرفر الجديد بصمت تام وبدون تيرمينال
WshShell.Run "java -jar PhishingDetector.jar", 0, False
